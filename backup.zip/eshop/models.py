from django.conf import settings
from django.contrib.auth.models import User, AbstractUser
from django.db import models
from django.db.models.signals import post_save, pre_delete
from django.dispatch import receiver


class Kategoria(models.Model):
    nazov = models.CharField(max_length=30)

    def __str__(self):
        return self.nazov


class Produkt(models.Model):
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    nazov = models.CharField(max_length=30)
    kategoria = models.ForeignKey(Kategoria, on_delete=models.CASCADE)
    popis = models.CharField(max_length=100)
    obrazok = models.ImageField(upload_to='productsImg', null=True, max_length=254)

    def __str__(self):
        return self.nazov


class Pouzivatel(models.Model):
    user = models.OneToOneField(User, primary_key=True, related_name='profile', on_delete=models.CASCADE)
    address = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __unicode__(self):
        return self.user.username

    @receiver(post_save, sender=User)
    def create_profile_for_user(sender, instance=None, created=False, **kwargs):
        if created:
            Pouzivatel.objects.get_or_create(user=instance)

    @receiver(pre_delete, sender=User)
    def delete_profile_for_user(sender, instance=None, **kwargs):
        if instance:
            user_profile = Pouzivatel.objects.get(user=instance)
            user_profile.delete()
