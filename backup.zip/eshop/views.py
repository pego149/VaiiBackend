from rest_framework import viewsets, generics
from rest_framework_simplejwt.views import TokenObtainPairView

from .serializers import *
from .permissions import IsOwnerProfileOrReadOnly


class KategoriaViewSet(viewsets.ModelViewSet):
    queryset = Kategoria.objects.all()
    serializer_class = KategoriaSerializer


class ProduktViewSet(viewsets.ModelViewSet):
    queryset = Produkt.objects.all()
    serializer_class = ProduktSerializer
    permission_classes = [IsOwnerProfileOrReadOnly]


class UserProfileViewSet(viewsets.ModelViewSet):
    queryset = Pouzivatel.objects.all()
    serializer_class = UserProfileSerializer


class MyTokenObtainPairView(TokenObtainPairView):
    serializer_class = MyTokenObtainPairSerializer
