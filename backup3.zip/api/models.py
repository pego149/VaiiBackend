from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils.translation import ugettext_lazy as _
from django.conf import settings


class Kategoria(models.Model):
    nazov = models.CharField(max_length=30)

    def __str__(self):
        return self.nazov


class Produkt(models.Model):
    nazov = models.CharField(max_length=30)
    kategoria = models.ForeignKey(Kategoria, on_delete=models.CASCADE)
    popis = models.CharField(max_length=100)
    obrazok = models.ImageField(upload_to='img', null=True)

    def __str__(self):
        return self.nazov


class Pouzivatel(AbstractUser):
    def __str__(self):
        return "{}".format(self.email)


class PouzivatelProfil(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='profile')
    title = models.CharField(blank=True, max_length=5)
    dob = models.DateField()
    address = models.CharField(max_length=255)
    country = models.CharField(max_length=50)
    city = models.CharField(max_length=50)
    zip = models.CharField(max_length=5)
    photo = models.ImageField(upload_to='img', null=True)
