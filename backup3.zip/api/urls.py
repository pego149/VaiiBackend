from django.conf.urls import url, include
from rest_framework import routers
from api.views import PouzivatelViewSet, KategoriaViewSet, ProduktViewSet

router = routers.DefaultRouter()
router.register(r'users', PouzivatelViewSet)
router.register(r'categories', KategoriaViewSet)
router.register(r'products', ProduktViewSet)

urlpatterns = [
    url(r'^', include(router.urls)),
    url(r'^auth/', include('rest_auth.urls')),
]